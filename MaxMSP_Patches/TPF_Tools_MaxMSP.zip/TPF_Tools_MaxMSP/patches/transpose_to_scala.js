//// js file save as "transpose_to_scale" ////

var transpose = jsarguments[1];
var note_array = new Array();
var note_str;

function list(a) {
	note_array = new Array();
	var i;
	for (i = 0; i 150) {
		break;
	}
}
outlet(0, note1);
}

function set_transpose(a) {
	transpose = a;
}

// end of js file //
